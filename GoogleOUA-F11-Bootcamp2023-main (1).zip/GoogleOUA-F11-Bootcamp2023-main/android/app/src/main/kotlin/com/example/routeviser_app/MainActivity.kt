package com.example.routeviser_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
